
import { createFeatureSelector, createSelector } from '@ngrx/store';
import { Bookmark } from 'src/app/core/models/bookmark.model';
import { BookmarkState } from '../Reducers/bookmark.reducers';

export const bookmarkSelector = createSelector(
  (state: BookmarkState) => state.bookmarks,
  (bookmarks: ReadonlyArray<Bookmark>) => bookmarks
);

/*
export const bookmarkUserSelector = createSelector(
  (state: BookmarkState) => state.bookmarks,
  (state: BookmarkState) => state.user,
  (bookmarks: ReadonlyArray<Bookmark>, user: Readonly<string>) => {
    return bookmarks.filter((bookmark: Bookmark) => bookmark.userName === user);
  }
); */



export const bookmark = createSelector(
  bookmarkSelector,
  // routeParams,
  // selectRouteParams,
  (bookmarks: ReadonlyArray<Bookmark>, { id }: {id: any}) => {
    return bookmarks.filter((m) => m.id === Number(id))[0];
  }
);