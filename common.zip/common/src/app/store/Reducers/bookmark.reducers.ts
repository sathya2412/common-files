
import {
  createFeatureSelector,
  createReducer,
  createSelector,
  on,
} from '@ngrx/store';
import { Bookmark, BookmarkList } from 'src/app/core/models/bookmark.model';
import {
  addBookmarks,
  addBookmarksSuccess,
  assignUser,
  deleteBookmarkSuccess,
  getBookmarksSuccess,
} from '../Actions/bookmark.action';

export interface BookmarkState {
  bookmarks: ReadonlyArray<Bookmark>;
  user: Readonly<string>;
}

const initialState: ReadonlyArray<Bookmark> = [];

export const bookmarkReducer = createReducer(
  initialState,
  on(getBookmarksSuccess, (state, { bookmarks }) => [...bookmarks]),
  on(addBookmarksSuccess, (state, { bookmark }) => [...state, bookmark]),
  on(deleteBookmarkSuccess, (state, { bookmarkId }) =>
    state.filter((bookmark) => bookmark.id !== bookmarkId)
  )
);

const initialUserSate = '';
export const userReducer = createReducer(
  initialUserSate,
  on(assignUser, (state, { user }) => user)
);

function mockBookmarks(): Bookmark[] {
    const data = localStorage.getItem('dataSource') || '[]';
    let dataSource = JSON.parse(data);
    if (!dataSource.length) {
      dataSource = BookmarkList;
      localStorage.setItem("dataSource", JSON.stringify(dataSource));
    } 
    return dataSource;
}