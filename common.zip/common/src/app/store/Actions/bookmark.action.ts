import { createAction, props } from '@ngrx/store';
import { Bookmark } from 'src/app/core/models/bookmark.model';

export const getBookmarks = createAction('[Bookmark] Get bookmark');
export const getBookmarksSuccess = createAction(
  '[Bookmark] Get bookmark success',
  (bookmarks: ReadonlyArray<Bookmark>) => ({ bookmarks })
  // props<{ bookmarks: ReadonlyArray<Bookmark> }>()
);
export const addBookmarks = createAction(
  '[Bookmark] Add bookmark',
  (bookmark: Bookmark) => ({ bookmark })
  // props<{ bookmark: Bookmark }>()
);
export const addBookmarksSuccess = createAction(
  '[Bookmark] Add bookmark success',
  // props<{ bookmark: Bookmark }>(),
  (bookmark: Bookmark) => ({ bookmark })
);

export const assignUser = createAction(
  '[User] assign user',
  (user: string) => ({ user })
);

export const deleteBookmark = createAction(
  '[Bookmark] Delete bookmark',
  (bookmarkId: number) => ({ bookmarkId })
);

export const deleteBookmarkSuccess = createAction(
  '[Bookmark] Delete bookmark success',
  (bookmarkId: number) => ({ bookmarkId })
);

export const logout = createAction('[User] logout');