import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, delay } from 'rxjs/operators';
import { Bookmark } from '../core/models/bookmark.model';

@Injectable({
  providedIn: 'root'
})
export class BookmarkService {private url = 'http://localhost:3000/bookmarks';
constructor(private http: HttpClient) {}

getBookmarks(): Observable<ReadonlyArray<Bookmark>> {
  return this.http.get<ReadonlyArray<Bookmark>>(this.url).pipe(
    catchError((error: HttpErrorResponse) => {
      console.error(error);
      return throwError(error);
    })
  );
}

addBookmarks(bookmark: Bookmark): Observable<Bookmark> {
  return this.http.post<Bookmark>(this.url, bookmark).pipe(
    catchError((error: HttpErrorResponse) => {
      console.error(error);
      return throwError(error);
    })
  );
}

deleteBookmark(bookmarkId: number) {
  return this.http.delete(`${this.url}/${bookmarkId}`).pipe(
    delay(2000),
    catchError((error: HttpErrorResponse) => {
      console.error(error);
      return throwError(error);
    })
  );
}

}
