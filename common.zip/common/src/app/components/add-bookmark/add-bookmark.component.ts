import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { Bookmark } from 'src/app/core/models/bookmark.model';

@Component({
  selector: 'app-add-bookmark',
  templateUrl: './add-bookmark.component.html',
  styleUrls: ['./add-bookmark.component.scss']
})
export class AddBookmarkComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<AddBookmarkComponent>,
    public formBuilder: FormBuilder) { }

  public bookMarkform: FormGroup = this.formBuilder.group({
    name: new FormControl('', [Validators.required, Validators.maxLength(30), this.findDuplicate]),
    url: new FormControl('', [Validators.required]),
    group: new FormControl('', [Validators.required])
  })


  public findDuplicate(control: AbstractControl): object | null {
    const name = control.value;
    const data: string | null = localStorage.getItem('dataSource') || '[]';
    const bookList = JSON.parse(data);
    
    const duplicate = bookList.filter((item: { name: string; }) => item.name.toLowerCase() === name.toLowerCase());

    if (duplicate.length && name.length > 0) {
        return { duplicateName: true };
    } else {
        return null;
    }
}

  ngOnInit(): void {
  }

  closeDialog(){
    this.bookMarkform.controls.name.markAsTouched();
    this.bookMarkform.controls.url.markAsTouched();
    this.bookMarkform.controls.group.markAsTouched();

    console.log('this.bookMarkform.controls.name', this.bookMarkform.controls.name);

    
    if (this.bookMarkform.valid) {
      const data = {
        name: this.bookMarkform.value.name,
        url: this.bookMarkform.value.url,
        group: this.bookMarkform.value.group
      };
      this.dialogRef.close(data);
    } else {
      return;
    }
    
  }


  getBookMarkList(): Bookmark[] {
    const data: string | null = localStorage.getItem('dataSource') || '[]';
    const dataSource = JSON.parse(data);
    console.log('---->popup', dataSource);
    return dataSource;
  }


}
