import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Bookmark, BookmarkList } from 'src/app/core/models/bookmark.model';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AddBookmarkComponent } from '../add-bookmark/add-bookmark.component';
import { BookmarkService } from 'src/app/Service/bookmark.service';
import { Store } from '@ngrx/store';
import { addBookmarks } from 'src/app/store/Actions/bookmark.action';

@Component({
  selector: 'app-bookmark-list',
  templateUrl: './bookmark-list.component.html',
  styleUrls: ['./bookmark-list.component.scss']
})
export class BookmarkListComponent implements OnInit {
  public dataSource: Bookmark[] = [];
  public displayedColumns = ['name', 'url', 'group', 'delete'];
  public toggleForm = false;
  public groupFilter = 'all';
 
  constructor(
    public formBuilder: FormBuilder,
    private bookmarkService: BookmarkService,
    private store: Store,
    public dialog: MatDialog) {
  }

  ngOnInit(): void {
    this.bookmarkService.getBookmarks().subscribe((res: any) => {
      console.log('res--->>>', res);
    })
    const data = localStorage.getItem('dataSource') || '[]';
    this.dataSource = JSON.parse(data);
    if (!this.dataSource.length) {
      this.dataSource = BookmarkList;
      localStorage.setItem("dataSource", JSON.stringify(this.dataSource));
    }  
  }

  openDialog(): void {
    const dialogRef = this.dialog.open(AddBookmarkComponent, {
      width: '400px'
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        console.log('result', result);
        /*this.bookmarkService.addBookmarks(result).subscribe((res)=>{
          console.log('added', res);
        });*/
        this.store.dispatch(addBookmarks(result));
        const data: string | null = localStorage.getItem('dataSource') || '[]';
        const dataSource = [...JSON.parse(data), ...[result]];
        localStorage.setItem("dataSource", JSON.stringify(dataSource));
        this.groupFilter = 'all'
        this.filterData(this.groupFilter);
      }
    });
  }



  deleteItem(name: string): void {
    this.bookmarkService.deleteBookmark(2).subscribe((res) => console.log('deleted'));
    const data: string | null = localStorage.getItem('dataSource') || '[]';
    const dataSource = JSON.parse(data);
    console.log('dataSource--->', dataSource);
    const filteredList = dataSource.filter((item: Bookmark, i: number) => item.name.toLowerCase() !== name.toLowerCase());
   
    localStorage.setItem("dataSource", JSON.stringify(filteredList));
   console.log('this.groupFilter', this.groupFilter);
    this.filterData(this.groupFilter);
  }

  filterData(event: string): void {
    const data: string | null = localStorage.getItem('dataSource') || '[]';
    if (event === 'all') {
      this.dataSource = JSON.parse(data);
      return;
    } 
    this.dataSource = JSON.parse(data).filter((item: { group: string; }, i: number) => item.group == event);
  }

}


